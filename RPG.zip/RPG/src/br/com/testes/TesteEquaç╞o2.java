package br.com.testes;

import javax.swing.JOptionPane;

public class TesteEqua��o2 {

	static Integer respostaGeral; // global

	public static void main(String[] args) {

		Integer pontosTeste = 0;

		respostaGeral = Integer.parseInt(JOptionPane
				.showInputDialog("Quantos metros de muro ter�o que ser feitos para isolar completamente esse terreno?"
						+ "\n0) 144m \n1) 576m \n2) 24m \n3) 18m \n4) 12m"));

		switch (respostaGeral) {
		case 0:
		case 1:
		case 2:
		case 3:
			System.out.println("\nResposta Incorreta\n");
			break;
		case 4:
			System.out.println("\nResposta Correta!");
			System.out.println("Voc� concluiu o teste com maestria\n");
			pontosTeste += 40;
			break;

		}

	}

}
