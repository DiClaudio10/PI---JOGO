package br.com.testes;

import java.util.Objects;

import javax.swing.JOptionPane;

public class TesteEqua��oVetor {

	static Integer respostaGeral; //global
	static String nome;
	
	public static void main(String[] args) {
		
		Integer pontosDoJogo = 0;

        Integer[] alternativas = new Integer[3]; //Vetor
        alternativas[0] = 70; //CERTA
        alternativas[1] = -70;
        alternativas[2] = 130;

        System.out.println("Resolva o c�lculo da fun��o abaixo: ");
        System.out.println("k(x) = 6x + 100\n" + "k(-5) = \n");
        System.out.println("Escolha uma das op��es abaixo: ");
        System.out.println("0) 70");
        System.out.println("1) -70");
        System.out.println("2) 130");

        // PRIMEIRA QUEST�O
        
        respostaGeral = Integer
                .parseInt(JOptionPane.showInputDialog("Escolha uma das op��es abaixo: \n0) 70\n1)-70 \n2) 130"));

        if (Objects.equals(alternativas[respostaGeral], alternativas[0])) { //Comparar o valor 'raiz' das variaveis
            System.out.println("\nResposta Correta!\n");
            System.out.println("Instrutor: " + nome + ", voc� foi bem no teste! Est� pronto para iniciar o caso.");
            pontosDoJogo = +20;

        } else {
            System.out.println("\nResposta Incorreta!\n");
            System.out.println("Obrigado por realizar o teste, sei que se sair� melhor em campo");
        }
		
	}

}
