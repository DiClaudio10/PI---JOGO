package br.com.testes;

import java.util.Objects;

import javax.swing.JOptionPane;

public class TesteEquacao {

	static Integer respostaGeral;
	
	public static void main(String[] args) {

		 String[] alternativas2 = new String[4];
         
         alternativas2[0] = "Apenas 3";
         alternativas2[1] = "25 e 3";
         alternativas2[2] = "25 e � 2";
         alternativas2[3] = "3 e � 2"; // Certa
         alternativas2[4] = "Apenas � 2";

         System.out.println("\nQuais s�o as ra�zes reais da equa��o x2 � x = 6?\n");

         respostaGeral = Integer.parseInt(JOptionPane.showInputDialog(
                 "Escolha uma das op��es abaixo: \n0) Apenas\n1) 25 e 3 \n2) 25 e � 2 \n3) 3 e � 2 \n4)Apenas � 2 "));

         if (Objects.equals(alternativas2[respostaGeral], alternativas2[3])){
             System.out.println("\nResposta Correta!\n");
             System.out.println("Revela alguma pista");


         } else {
             System.out.println("\nResposta Incorreta!\n");
             System.out.println("Suspeito n�o liga para o detetive");
         }
     
		
	}

}
