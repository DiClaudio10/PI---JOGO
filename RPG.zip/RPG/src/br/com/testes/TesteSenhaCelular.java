package br.com.testes;

import javax.swing.JOptionPane;

public class TesteSenhaCelular {

    static Integer respostaGeral; // global
	
	public static void main(String[] args) {

        Integer pontosDoJogo = 0;
		
		System.out.println("Hacker: Vamos ver se vai funcionar!");

        JOptionPane.showMessageDialog(null, "Digite a senha: ");

        do {

            respostaGeral = Integer
                    .parseInt(JOptionPane.showInputDialog("\n1) 1227\n2)1226 \n3) 1225 \n 4)1217\n 5)1272 "));

            switch (respostaGeral) {

                case 1:
                    System.out.println("Senha Correta");
                    pontosDoJogo += 30;
                    break;

                case 2:
                case 3:
                case 4:
                case 5:
                    System.out.println("Senha Incorreta");
                    break;

                default:
                    System.out.println("Senha Inv�lida");
            }

        } while (respostaGeral != 1);
        JOptionPane.showMessageDialog(null, "Celular Desbloqueado");
		
	}

}
